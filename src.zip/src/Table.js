import React, { useState } from 'react';
import './styles.css'; 

const Table = () => {
  const [data, setData] = useState([
    { id: 1, name: 'Peter England Shirt', price:  2299, category: 'Fashion' },
    { id: 2, name: 'Allen Solly Shirt', price: 2799, category: 'Fashion' },
    { id: 3, name: 'Van Heusen Shirt', price: 2599, category: 'Fashion' },
  ]);
  const [search, Term] = useState('');

  const handleDelete = (id) => {
    setData(data.filter((item) => item.id !== id));
  };

  const filteredData = data.filter((item) =>
    item.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <div className="container">
        <div className="search">
          <input type="text" placeholder="Search" value={search} onChange={(e) => Term(e.target.value)}/>
        </div>
        <div className="create">
          <button className="button">Create Product</button>
        </div>
      </div>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Price</th>
            <th>Category</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {filteredData.map((item) => (
            <tr key={item.id}>
              <td>{item.name}</td>
              <td>{item.price}</td>
              <td>{item.category}</td>
              <td>
                <button className="read-button" onClick={() => alert(`Read: {item.name}`)}>Read</button>
                <button className="add-button" onClick={() => alert(`Add: {item.name}`)}>Add</button>
                <button className="delete-button" onClick={() => handleDelete(item.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Table;
