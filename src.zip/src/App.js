import React from 'react';
import Table from './Table';

function App() {
  return (
    <div className="App">
      <h2>Search Product</h2>
      <Table />
    </div>
  );
}

export default App;
